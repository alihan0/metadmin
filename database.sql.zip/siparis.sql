-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 17 Mar 2022, 23:37:46
-- Sunucu sürümü: 8.0.28-0ubuntu0.20.04.3
-- PHP Sürümü: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `siparis`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `accounts`
--

CREATE TABLE `accounts` (
  `id` int NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` int NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Tablo döküm verisi `accounts`
--

INSERT INTO `accounts` (`id`, `firstname`, `lastname`, `username`, `email`, `password`, `status`, `last_login`, `created_at`) VALUES
(1, 'Alihan', 'Öztürk', 'admin', 'alihan@metatige.com', '7af919c5b6a62bc8fe0857c5cda402ba808292186411cd0ef54c82023df2f24b572a522a', 2, '2022-03-17 22:57:00', '2022-03-09 20:43:00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `customers`
--

CREATE TABLE `customers` (
  `id` int NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `il` varchar(255) DEFAULT NULL,
  `ilce` varchar(255) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Tablo döküm verisi `customers`
--

INSERT INTO `customers` (`id`, `firstname`, `lastname`, `email`, `phone`, `address`, `il`, `ilce`, `status`, `created_at`) VALUES
(5, 'alihan', 'öztürk', NULL, '0546497129', 'ankara', 'ankara', 'yenimahalle', 2, '2022-03-13 14:39:00'),
(6, 'alihan', 'öztürk', NULL, 'telefon ', 'adres', 'Adana', 'Aladağ', 2, '2022-03-13 14:39:00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `logs`
--

CREATE TABLE `logs` (
  `id` int NOT NULL,
  `user` int NOT NULL,
  `log_text` text NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Tablo döküm verisi `logs`
--

INSERT INTO `logs` (`id`, `user`, `log_text`, `created_at`) VALUES
(1, 1, 'Giriş Yapıldı', '2022-03-09 10:03:00'),
(2, 1, 'Giriş Yapıldı', '2022-03-09 19:54:00'),
(3, 2, 'Hesap oluşturuldu', '2022-03-09 20:15:00'),
(4, 1, 'Hesap oluşturuldu', '2022-03-09 20:16:00'),
(5, 1, 'Yönetici Silindi', '2022-03-09 20:29:00'),
(6, 1, 'Yönetici Silindi', '2022-03-09 20:30:00'),
(7, 1, 'Hesap oluşturuldu', '2022-03-09 20:30:00'),
(8, 1, 'Yönetici Silindi', '2022-03-09 20:30:00'),
(9, 1, 'Hesap oluşturuldu', '2022-03-09 20:31:00'),
(10, 1, 'Yönetici Silindi', '2022-03-09 20:31:00'),
(11, 1, 'Hesap oluşturuldu', '2022-03-09 20:32:00'),
(12, 1, 'Yönetici Silindi', '2022-03-09 20:32:00'),
(13, 1, 'Hesap oluşturuldu', '2022-03-09 20:32:00'),
(14, 1, 'Yönetici Silindi', '2022-03-09 20:32:00'),
(15, 1, 'Hesap oluşturuldu', '2022-03-09 20:33:00'),
(16, 1, 'Yönetici Silindi', '2022-03-09 20:33:00'),
(17, 1, 'Müşteri oluşturuldu', '2022-03-09 20:42:00'),
(18, 1, 'Yönetici Silindi', '2022-03-09 20:42:00'),
(19, 1, 'Hesap oluşturuldu', '2022-03-09 20:43:00'),
(20, 1, 'Müşteri oluşturuldu', '2022-03-09 20:50:00'),
(21, 1, 'Müşteri Silindi', '2022-03-09 20:50:00'),
(22, 1, 'Müşteri Güncellendi', '2022-03-09 21:02:00'),
(23, 1, 'Müşteri Güncellendi', '2022-03-09 21:02:00'),
(24, 1, 'Sipariş Silindi', '2022-03-10 00:03:00'),
(25, 1, 'Sipariş Reddedildi', '2022-03-10 00:05:00'),
(26, 1, 'Sipariş Reddedildi', '2022-03-10 00:06:00'),
(27, 1, 'Sipariş Onaylandı', '2022-03-10 00:07:00'),
(28, 1, 'Çıkış Yapıldı', '2022-03-10 00:40:00'),
(29, 9, 'Giriş Yapıldı', '2022-03-10 00:43:00'),
(30, 9, 'Çıkış Yapıldı', '2022-03-10 00:52:00'),
(31, 1, 'Giriş Yapıldı', '2022-03-10 00:53:00'),
(32, 1, 'Giriş Yapıldı', '2022-03-10 10:46:00'),
(33, 1, 'Sipariş Reddedildi', '2022-03-10 10:50:00'),
(34, 1, 'Sipariş Silindi', '2022-03-10 11:30:00'),
(35, 1, 'Sipariş Silindi', '2022-03-10 11:35:00'),
(36, 1, 'Sipariş İptal Edildi', '2022-03-10 11:50:00'),
(37, 1, 'Sipariş Depoda', '2022-03-10 11:50:00'),
(38, 1, 'Sipariş İptal Edildi', '2022-03-10 11:51:00'),
(39, 1, 'Sipariş Depoda', '2022-03-10 11:51:00'),
(40, 1, 'Sipariş Yolda', '2022-03-10 11:51:00'),
(41, 1, 'Sipariş İade Edildi', '2022-03-10 11:51:00'),
(42, 1, 'Sipariş Teslim Edildi', '2022-03-10 11:52:00'),
(43, 1, 'Sipariş Yolda', '2022-03-10 11:52:00'),
(44, 1, 'Sipariş İptal Edildi', '2022-03-10 11:53:00'),
(45, 1, 'Sipariş Depoda', '2022-03-10 11:53:00'),
(46, 1, 'Sipariş İptal Edildi', '2022-03-10 11:53:00'),
(47, 1, 'Sipariş İptal Edildi', '2022-03-10 11:54:00'),
(48, 1, 'Sipariş İptal Edildi', '2022-03-10 11:54:00'),
(49, 1, 'Sipariş Depoda', '2022-03-10 11:54:00'),
(50, 1, 'Sipariş Yolda', '2022-03-10 11:54:00'),
(51, 1, 'Sipariş Teslim Edildi', '2022-03-10 11:54:00'),
(52, 1, 'Sipariş İade Edildi', '2022-03-10 11:54:00'),
(53, 1, 'Sipariş Teslim Edildi', '2022-03-10 11:57:00'),
(54, 1, 'Sipariş Silindi', '2022-03-10 11:59:00'),
(55, 1, 'Sipariş Silindi', '2022-03-10 11:59:00'),
(56, 1, 'Giriş Yapıldı', '2022-03-10 18:34:00'),
(57, 1, 'Giriş Yapıldı', '2022-03-11 20:31:00'),
(58, 1, 'Giriş Yapıldı', '2022-03-12 19:37:00'),
(59, 1, 'Müşteri oluşturuldu', '2022-03-12 19:50:00'),
(60, 1, 'Müşteri Güncellendi', '2022-03-12 19:50:00'),
(61, 1, 'Müşteri oluşturuldu', '2022-03-12 20:04:00'),
(62, 1, 'Müşteri oluşturuldu', '2022-03-12 20:08:00'),
(63, 1, 'Sipariş İptal Edildi', '2022-03-12 20:25:00'),
(64, 1, 'Sipariş Silindi', '2022-03-12 20:26:00'),
(65, 1, 'Sipariş Silindi', '2022-03-12 20:28:00'),
(66, 1, 'Sipariş Silindi', '2022-03-12 20:28:00'),
(67, 1, 'Sipariş Depoda', '2022-03-12 20:41:00'),
(68, 1, 'Sipariş Yolda', '2022-03-12 20:41:00'),
(69, 1, 'Sipariş Teslim Edildi', '2022-03-12 20:41:00'),
(70, 1, 'Sipariş İade Edildi', '2022-03-12 20:41:00'),
(71, 1, 'Sipariş İptal Edildi', '2022-03-12 20:42:00'),
(72, 1, 'Sipariş İptal Edildi', '2022-03-12 20:42:00'),
(73, 1, 'Sipariş İptal Edildi', '2022-03-12 20:42:00'),
(74, 1, 'Sipariş İptal Edildi', '2022-03-12 20:42:00'),
(75, 1, 'Sipariş Silindi', '2022-03-12 20:46:00'),
(76, 1, 'Sipariş Depoda', '2022-03-12 23:28:00'),
(77, 1, 'Giriş Yapıldı', '2022-03-13 14:03:00'),
(78, 1, 'Sipariş Depoda', '2022-03-13 14:05:00'),
(79, 1, 'Müşteri oluşturuldu', '2022-03-13 14:35:00'),
(80, 1, 'Müşteri Silindi', '2022-03-13 14:35:00'),
(81, 1, 'Müşteri Silindi', '2022-03-13 14:35:00'),
(82, 1, 'Müşteri Silindi', '2022-03-13 14:35:00'),
(83, 1, 'Müşteri Güncellendi', '2022-03-13 14:39:00'),
(84, 1, 'Müşteri Güncellendi', '2022-03-13 14:39:00'),
(85, 1, 'Müşteri Güncellendi', '2022-03-13 14:39:00'),
(86, 1, 'Giriş Yapıldı', '2022-03-15 18:27:00'),
(87, 1, 'Giriş Yapıldı', '2022-03-16 19:26:00'),
(88, 1, 'Giriş Yapıldı', '2022-03-17 22:57:00'),
(89, 1, 'Sipariş Yolda', '2022-03-17 23:21:00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `customer` int DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `delivery_at` datetime DEFAULT NULL,
  `kapora` int DEFAULT NULL,
  `total_price` varchar(222) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `order_desc` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `order_detail` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `status` int DEFAULT NULL,
  `created_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Tablo döküm verisi `orders`
--

INSERT INTO `orders` (`id`, `customer`, `delivery_date`, `delivery_at`, `kapora`, `total_price`, `order_desc`, `order_detail`, `status`, `created_at`) VALUES
(4, 1, '2022-03-04', '2022-03-12 20:41:00', 123123, '1', 'qw', '{\"product\":[{\"ad\":\"1\",\"ozellik\":\"1\",\"fiyat\":\"1\"}]}', 5, '2022-03-09'),
(9, 1, '2022-03-27', '2022-03-10 11:57:00', 234, '0', '234234', '{\"product\":[{\"ad\":\"\",\"ozellik\":\"\",\"fiyat\":\"\"}]}', 0, '2022-03-10'),
(11, 1, '2022-03-09', NULL, 23234, '234', '234234', '{\"product\":[{\"ad\":\"234\",\"ozellik\":\"234\",\"fiyat\":\"234\"}]}', 0, '2022-03-10'),
(12, 1, '2022-03-31', NULL, 1000, '18500', 'test sipariş', '{\"product\":[{\"ad\":\"koltuk\",\"ozellik\":\"koltuk\",\"fiyat\":\"2000\"},{\"ad\":\"kanepe\",\"ozellik\":\"kanepe\",\"fiyat\":\"3000\"},{\"ad\":\"masa\",\"ozellik\":\"masa\",\"fiyat\":\"10000\"},{\"ad\":\"sandalye\",\"ozellik\":\"sandalye\",\"fiyat\":\"3500\"}]}', 2, '2022-03-20'),
(13, 3, '2022-03-20', NULL, 1000, '5000', 'testtesttd', '{\"product\":[{\"ad\":\"\\u00fcr\\u00fcn1\"},{\"ad\":\"\\u00fcr\\u00fcn2\"}]}', 3, '2022-03-17'),
(14, 5, '2022-04-03', NULL, 1000, '5000', 'test', '{\"product\":[{\"ad\":\"test\"},{\"ad\":\"test\"}]}', 0, '2022-03-01'),
(15, 5, '2022-03-19', '2022-03-17 00:00:00', 1000, '5000', 'test', '{\"product\":[{\"ad\":\"test\"},{\"ad\":\"test\"}]}', 5, '2022-03-13'),
(16, 1, '2022-03-19', NULL, 123123, '123123', 'eef', '{\"product\":[{\"ad\":\"\"}]}', 1, '2022-03-03'),
(17, 5, '2022-03-26', NULL, 1000, '5000', 'test açıklama', '{\"product\":[{\"ad\":\"\\u00fcr\\u00fcn 1 \"},{\"ad\":\"\\u00fcr\\u00fcn 2\"}]}', 1, '2022-03-19'),
(18, 5, '2022-03-20', NULL, 1000, '5000', 'test', '{\"product\":[{\"ad\":\"\\u00fcr\\u00fcn 1\"},{\"ad\":\"\\u00fcr\\u00fcn 2\"}]}', 1, '2022-03-13'),
(19, 5, '2022-03-13', NULL, 1000, '5000', 'rws', '{\"product\":[{\"ad\":\"\\u00fcr\\u00fcn 1\",\"ozellik\":\"\\u00f6zellik 1\"}]}', 1, '2022-03-11'),
(20, 5, '2022-03-17', '2022-03-27 00:00:00', 2000, '8000', 'test123123', '{\"product\":[{\"ad\":\"\\u00fcr\\u00fcn 1\",\"ozellik\":\"\\u00fcr\\u00fcn 1\"},{\"ad\":\"\\u00fcr\\u00fcn 2\",\"ozellik\":\"\\u00fcr\\u00fcn 2\"}]}', 5, '2022-03-27');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Tablo için AUTO_INCREMENT değeri `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- Tablo için AUTO_INCREMENT değeri `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
